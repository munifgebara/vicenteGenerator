const superagent = require('superagent');
const http = require('http');

const apiBase = 'http://127.0.0.1:8080/api';
console.log("\n\n\n\n\n\n");
let token = "SEM TOKEN";
let tokenC = {};
let grupo = "SEM GRUPO";
console.log("Logando", token);
superagent.post(`http://127.0.0.1:8080/api/token/login/bypassword`)
    .send(JSON.stringify({
        login: "admin@munif.com.br",
        senha: "qwe123"
    }))
    .set('Accept', 'application/json, text/plain, */*')
    .set('Content-Type', 'application/json;charset=UTF-8')
    .then(function (res) {
        tokenC = res.body;
        token = tokenC.token.token;
        if (tokenC.token.usuario.grupos && tokenC.token.usuario.grupos.length > 0) {
            grupo = tokenC.token.usuario.grupos[tokenC.token.usuario.grupos.length - 1];
        }
        console.log("Logado= TOKEN====>", token, "GRUPO ", grupo.nome);
        inserePessoa();
    });


function randomArray(array) {
    let r = array[Math.floor(Math.random() * array.length)];
    return r;
}
function randomString() {
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for (var i = 0; i < 5; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

function inserePessoa() {
    let entidade = `pessoa`;

    console.log("Inserindo ${entidade}");
    ["Duda", "Vicente", "Munif"].forEach(p => {
        superagent.get('http://127.0.0.1:8080/api/' + entidade + '/new').set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').end((err, res) => {
            if (err) { return console.log(err); }

            let obj = res.body;

            obj.nome = p;
            console.log(entidade + " novo ", obj.nome);

            superagent.post(`http://127.0.0.1:8080/api/${entidade}`).send(obj).set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').then(function (res) {
                console.log(entidade + " Inserido ", res.body.nome);
            });
        });
    });
}

function inserePais() {

    console.log("Inserindo País");
    ["Brasil", "Paraguay", "Argentina"].forEach(p => {
        superagent.get('http://127.0.0.1:8080/api/pais/new').set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').end((err, res) => {
            if (err) { return console.log(err); }

            let pais = res.body;

            pais.nome = p;
            console.log("País novo ", pais.nome);

            superagent.post(`http://127.0.0.1:8080/api/pais`).send(pais).set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').then(function (res) {
                console.log("País Inserido ", res.body.nome);
                setTimeout(insereEstado, 1000);
            });
        });
    });
}

function insereEstado() {
    superagent.get('http://127.0.0.1:8080/api/pais').set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').end((err, res) => {
        let paises = res.body.values;
        superagent.get('http://127.0.0.1:8080/api/estado/new').set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').end((err, res) => {
            let estado = res.body;
            estado.nome = randomString();
            estado.pais = randomArray(paises);
            console.log(estado.nome, estado.pais);
            superagent.post(`http://127.0.0.1:8080/api/estado`).send(estado).set('authorization', token).set('group', grupo.codigo).set('Accept', 'application/json').then(function (res) {
                console.log("Estado Inserido ", res.body.nome);
                //setTimeout(insereEstado, 1000);
            });

        });

    });

}